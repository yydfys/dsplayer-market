# Songloft DsPlayer binary plugin

- Upstream: https://github.com/songloft-org/songloft
- Version: `2.13.2`
- Runtime: Android ARM64 native binary (`CGO_ENABLED=0`, full build with embedded Lynx Web UI)
- Default service port: `58091`
- Health check: `GET /api/v1/health`

The plugin stores its SQLite database, logs, covers, cache, and JS plugin data under the DsPlayer plugin directory. The default command points the music directory at `__sdcard__/Music`; change `-music` in the service configuration if the library is elsewhere.

The upstream server defaults to `admin` / `admin` when no credentials are supplied. Change the password immediately after first login. Do not expose this service to an untrusted network without configuring credentials and reviewing the bind/network policy.

This package uses the Lynx Web embedded asset from the `songloft-player-lynx` `dev` release (`songloft-lynx-web-embedded.tar.gz`, asset SHA-256 `97c65342b25d159a69b01f81573f0dd785cdab26219446c99a1a1bbf61401245`). The Go binary embeds the Web UI and serves it from the root URL. Optional metadata probing, remote cover extraction, and transcoding require Android-compatible `ffprobe` / `ffmpeg` binaries supplied separately; the plugin package does not include them.

## Build provenance

Built from upstream commit `adc739d13197ab604cad55c77919743f2cc96080` with Go `1.26.1`. This package additionally integrates the Android DNS resolver from the supplied `dns.go` source and initializes it before Songloft starts its services. Version 2.13.2 also filters Android loopback/unspecified DNS addresses such as `[::1]:53`, which are unavailable to the standalone plugin process:

```sh
CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -tags lite -trimpath \
  -ldflags='-s -w -X songloft/internal/version.Version=2.13.0 \
  -X songloft/internal/version.GitCommit=adc739d -X songloft/internal/version.BuildType=lite \
  -X songloft/internal/version.BuildTime=2026-10-08T11:40:00Z' \
  -o dist/songloft/bin/songloft-android ./
```

The source is Apache License 2.0. Redistributed packages must retain `LICENSE` and `NOTICE` attribution files. This plugin package includes copies of both files.
